#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup(){

    std::string url = "http://www.bjs.gov:8080/bjs/ncvs/v2/personal/2016?format=json";
    
    // Now parse the JSON
    bool parsingSuccessful = json.open(url);
    
    if (parsingSuccessful)
    {
        ofLogNotice("ofApp::setup") << json.getRawString(true);
    } else {
        ofLogNotice("ofApp::setup") << "Failed to parse JSON.";
    }
    
    
    
}

//--------------------------------------------------------------
void ofApp::update(){

    
}

//--------------------------------------------------------------
void ofApp::draw(){
    
    ofBackground(0);
    ofSetColor(255);
    
    for (Json::ArrayIndex i = 0; i < json["personalData"].size(); ++i)
    {
        
        std::string year  = json["personalData"][i]["year"].asString();
        int nYear = std::stoi(year);
        
        std::string age = json["personalData"][i]["ager"].asString();
        int nAge = std::stoi(age);
        
        std::string gender   = json["personalData"][i]["gender"].asString();
        int nGender = std::stoi(gender);
        
        std::string text   = "Year= " + year + " age= " + age + " gender= " + gender;
        ofDrawBitmapString(text, 20, i * 24 + 40);
        
    }
    
    
    
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){

}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y){

}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y){

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){ 

}
